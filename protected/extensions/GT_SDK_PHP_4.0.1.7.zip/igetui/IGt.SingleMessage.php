<?php 

Class IGtSingleMessage extends IGtMessage{
	
	public function __construct(){
		parent::__construct();
	}

}